/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "instance_display.h"

static FL_PUP_ENTRY fdmenu_frame_menu_0[] =
{ 
	/*  itemtext   callback  shortcut   mode */
	{ "New Slot",	0,	"",	 FL_PUP_NONE},
	{ "Delete Frame",	0,	"",	 FL_PUP_NONE},
	{0}
};

FD_instance_display *create_form_instance_display(int n_slots)
{
	int i;
	FL_OBJECT *obj;
	FD_instance_display *fdui = (FD_instance_display *) fl_calloc(1, sizeof(*fdui));

	fdui -> slot = fl_calloc(n_slots, sizeof (FL_OBJECT *));

	fdui -> instance_display = fl_bgn_form(FL_NO_BOX, 315, 130 +n_slots*40);

	obj = fl_add_box(FL_RFLAT_BOX,0,0,315,415,"");
	obj = fl_add_box(FL_UP_BOX,0,0,320,30,"");
	obj = fl_add_box(FL_FRAME_BOX,0,30,320,90,"");

	fdui -> frame_menu = obj = fl_add_menu(FL_PULLDOWN_MENU,5,5,60,20,"Frame");
	fl_set_object_callback(obj,frame_menu_cb,0);
	fl_set_menu_entries(obj, fdmenu_frame_menu_0);

	fdui -> new_slot_menu = obj = fl_add_menu(FL_PULLDOWN_MENU,60,5,60,20,"New Slot");
	fl_set_object_callback(obj,new_slot_cb,0);

	fdui -> frame_id = obj = fl_add_input(FL_NORMAL_INPUT,110,40,180,30,"Frame Id");
	fl_set_object_color(obj,FL_WHITE,FL_WHITE);
	fl_set_object_lsize(obj,FL_NORMAL_SIZE);
	fl_set_object_callback(obj,frame_id_cb,0);

	fdui -> isa = obj = fl_add_input(FL_NORMAL_INPUT,110,80,180,30,"Isa");
	fl_set_object_color(obj,FL_WHITE,FL_WHITE);
	fl_set_object_lsize(obj,FL_NORMAL_SIZE);
	fl_set_object_callback(obj,isa_cb,0);

	for (i = 0; i < n_slots; i++)
	{
		fdui -> slot[i] = obj = fl_add_input(FL_NORMAL_INPUT,110,130 + i*40,180,30,"Slot");
		fl_set_object_color(obj,FL_WHITE,FL_WHITE);
		fl_set_object_lsize(obj,FL_NORMAL_SIZE);
		fl_set_object_callback(obj,slot_cb,0);
	}

	fl_end_form();

	fdui->instance_display->fdui = fdui;

	return fdui;
}

