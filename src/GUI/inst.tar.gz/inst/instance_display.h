/** Header file generated with fdesign on Wed May  8 18:50:20 2002.**/

#ifndef FD_instance_display_h_
#define FD_instance_display_h_

/** Callbacks, globals and object handlers **/
extern void frame_menu_cb(FL_OBJECT *, long);
extern void new_slot_cb(FL_OBJECT *, long);
extern void frame_id_cb(FL_OBJECT *, long);
extern void isa_cb(FL_OBJECT *, long);
extern void slot_cb(FL_OBJECT *, long);


/**** Forms and Objects ****/
typedef struct {
	FL_FORM *instance_display;
	void *vdata;
	char *cdata;
	long  ldata;
	FL_OBJECT *frame_menu;
	FL_OBJECT *new_slot_menu;
	FL_OBJECT *frame_id;
	FL_OBJECT *isa;
	FL_OBJECT **slot;
} FD_instance_display;

extern FD_instance_display * create_form_instance_display(int);

#endif /* FD_instance_display_h_ */
