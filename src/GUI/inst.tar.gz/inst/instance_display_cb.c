#include "forms.h"
#include "instance_display.h"

/*** callbacks and freeobj handles for form instance_display ***/
void frame_menu_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void new_slot_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void frame_id_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void isa_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}

void slot_cb(FL_OBJECT *ob, long data)
{
  /* fill-in code for callback */
}



