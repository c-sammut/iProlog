#include "forms.h"
#include "instance_display.h"

int main(int argc, char *argv[])
{
	FD_instance_display *fd_instance_display;

	fl_initialize(&argc, argv, 0, 0, 0);
	fd_instance_display = create_form_instance_display(5);

	/* fill-in form initialization code */

	/* show the first form */
	fl_show_form(fd_instance_display->instance_display,FL_PLACE_CENTERFREE,FL_FULLBORDER,"instance_display");
	fl_do_forms();
	return 0;
}
